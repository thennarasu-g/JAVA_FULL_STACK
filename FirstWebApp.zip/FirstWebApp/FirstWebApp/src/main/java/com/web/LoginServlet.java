package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // TODO: change DB details
        String url = "jdbc:mysql://localhost:3306/companydb";
        String dbUser = "root";
        String dbPass = "root@1234";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(url, dbUser, dbPass);

            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                out.println("<h2>Login Successful ✅</h2>");
                out.println("<h3>Welcome, " + username + "</h3>");
            } else {
                out.println("<h2>Invalid Credentials ❌</h2>");
                out.println("<a href='login.jsp'>Try again</a>");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h2>Server Error </h2>");
            out.println("<pre>" + e.getMessage() + "</pre>");
        }
    }
}